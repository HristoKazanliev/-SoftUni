﻿namespace P02_FootballBetting.Data.Common
{
    public class DbConfig
    {
        public const string ConnectionString =
            @"Server=DESKTOP-KE01FV1\SQLEXPRESS01;Database=BET365;Integrated Security=True;Encrypt=False;";
    }
}