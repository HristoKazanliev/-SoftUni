﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-KE01FV1\SQLEXPRESS01;Database=Trucks;Trusted_Connection=True";
    }
}