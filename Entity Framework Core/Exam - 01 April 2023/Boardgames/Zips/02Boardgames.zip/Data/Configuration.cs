﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-KE01FV1\SQLEXPRESS01;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
