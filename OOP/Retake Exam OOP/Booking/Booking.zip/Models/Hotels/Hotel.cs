﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BookingApp.Models.Bookings.Contracts;
using BookingApp.Models.Hotels.Contacts;
using BookingApp.Models.Rooms;
using BookingApp.Models.Rooms.Contracts;
using BookingApp.Repositories;
using BookingApp.Repositories.Contracts;
using BookingApp.Utilities.Messages;

namespace BookingApp.Models.Hotels
{
    public class Hotel : IHotel
    {
        private string fullName;
        private int category;
        private IRepository<IRoom> roomsTest;
        private IRepository<IBooking> bookingsTest;
        private RoomRepository roomRepository;
        private BookingRepository bookingRepository;
        private List<IRoom> rooms = new List<IRoom>();
        private List<IBooking> bookings = new List<IBooking>();

        public Hotel(string fullName, int category)
        {
            FullName = fullName;
            Category = category;
            //rooms = new List<IRoom>();
            //bookings = new List<IBooking>();
        }

        public string FullName
        {
            get => fullName;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException(ExceptionMessages.HotelNameNullOrEmpty);
                }
                fullName = value;
            }
        }

        public int Category
        {
            get => category;
            private set
            {
                if (value < 1 || value > 5)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidCategory);
                }
                category = value;
            }
        }


        public IRepository<IRoom> Rooms
        {
            get => (IRepository<IRoom>)rooms;
            set => rooms = (List<IRoom>)value;
        }

        public IRepository<IBooking> Bookings
        {
            get => (IRepository<IBooking>)bookings;
            set => bookings = (List<IBooking>)value;
        }

        public double Turnover => TotalPaid();

        private double TotalPaid()
        {
            double total = rooms.Sum(r => r.PricePerNight) * bookings.Sum(b => b.ResidenceDuration);
            return Math.Round(total, 2);
        }
    }
}
