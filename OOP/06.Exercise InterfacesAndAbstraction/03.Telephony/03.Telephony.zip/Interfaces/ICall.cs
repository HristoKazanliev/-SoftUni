﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony.Interfaces
{
    public interface ICall
    {
        string Call(string number);
    }
}
