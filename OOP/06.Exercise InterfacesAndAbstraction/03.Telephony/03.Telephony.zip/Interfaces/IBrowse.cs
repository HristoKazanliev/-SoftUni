﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony.Interfaces
{
    public interface IBrowse
    {
        string Browse(string number);
    }
}
