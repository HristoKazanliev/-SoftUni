﻿using PlanetWars.Models.MilitaryUnits.Contracts;
using PlanetWars.Models.Planets.Contracts;
using PlanetWars.Models.Weapons.Contracts;
using PlanetWars.Utilities.Messages;
using PlanetWars.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using PlanetWars.Models.MilitaryUnits;

namespace PlanetWars.Models.Planets
{
    public class Planet : IPlanet
    {
        private string name;
        private double budget;
        private double militaryPower;
        private UnitRepository unitRepository;
        private WeaponRepository weaponRepository;

        public Planet(string name, double budget)
        {
            Name = name;
            Budget = budget;
            unitRepository = new UnitRepository();
            weaponRepository = new WeaponRepository();
        }

        public string Name
        {
            get => name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.InvalidPlanetName);
                }
                name = value;
            }
        }

        public double Budget
        {
            get => budget;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidBudgetAmount);
                }
                budget = value;
            }
        }

        public double MilitaryPower
        {
            get => militaryPower;
            private set
            {
               militaryPower = TotalAmount();
            }
        }
        public IReadOnlyCollection<IMilitaryUnit> Army => (IReadOnlyCollection<IMilitaryUnit>)unitRepository;

        public IReadOnlyCollection<IWeapon> Weapons => (IReadOnlyCollection<IWeapon>)weaponRepository;

        public void AddUnit(IMilitaryUnit unit)
        {
            unitRepository.AddItem(unit);
        }

        public void AddWeapon(IWeapon weapon)
        {
            weaponRepository.AddItem(weapon);
        }

        public string PlanetInfo()
        {
            string unitsCount = unitRepository.Models.Count == 0 ? "No units" : string.Join(", ", unitRepository.Models);
            string combatEquipment = weaponRepository.Models.Count == 0 ? "No weapons" : string.Join(", ", weaponRepository.Models);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Planet: {Name}");
            sb.AppendLine($"--Budget: {Budget} billion QUID");
            sb.AppendLine($"--Forces: {unitsCount}");
            sb.AppendLine($"--Combat equipment: {combatEquipment}");
            sb.AppendLine($"--Military Power: {MilitaryPower}");

            return sb.ToString().TrimEnd();
        }

        public void Profit(double amount)
        {
            budget += amount;
        }

        public void Spend(double amount)
        {
            if (budget < amount)
            {
                throw new InvalidOperationException(ExceptionMessages.UnsufficientBudget);
            }
            budget -= amount;
        }

        public void TrainArmy()
        {
            foreach (var item in unitRepository.Models)
            {
                item.IncreaseEndurance();
            }
        }

        private double TotalAmount()
        {
            double sumOfUnitEndurances = unitRepository.Models.Sum(m => m.EnduranceLevel);
            double sumOfWeaponDestructionLevels = weaponRepository.Models.Sum(w => w.DestructionLevel);
            double totalAmount = sumOfUnitEndurances + sumOfWeaponDestructionLevels;

            if (unitRepository.Models.GetType().Name == "AnonymousImpactUnit")
            {
                totalAmount += totalAmount * 30 / 100;
            }


            if (weaponRepository.Models.GetType().Name == "NuclearWeapon ")
            {
                totalAmount += totalAmount * 45 / 100;
            }

            return Math.Round(totalAmount, 3);
        }
    }
}
