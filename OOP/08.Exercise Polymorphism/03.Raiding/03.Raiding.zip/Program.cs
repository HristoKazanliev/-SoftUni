﻿using System;
using _03.Raiding.Core;

namespace _03.Raiding
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Start();
        }
    }
}
